package blooddata;

import java.util.Scanner;

public class RunBloodData {
    static Scanner sc = new Scanner(System.in);
     
     public static void main(String[] args) {
         String bt, rh = null;
         System.out.print("Enter your blood type: ");
         bt = sc.nextLine();
         System.out.print("Enter your Rhesus Factor (+ or -): ");
         rh = sc.nextLine();
         
         if(bt.isEmpty() && rh.isEmpty()){
             BloodData bd = new BloodData();
             bd.Display();
         }
         else{
             BloodData bd = new BloodData(bt, rh);
             bd.Display();
         }
         
         
     }
}
