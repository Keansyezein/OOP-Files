package blooddata;

import java.util.Scanner;

 class BloodData {
     String BloodType;
     String rhFactor;
     
     public BloodData(){
         BloodType = "O";
         rhFactor = "+";
     }
     public BloodData(String bt, String rh){
         BloodType = bt;
         rhFactor = rh;
     }
     
     public void Display(){
         System.out.println(BloodType + rhFactor + " is added to the blood bank.");
     }
     
}
    

    
